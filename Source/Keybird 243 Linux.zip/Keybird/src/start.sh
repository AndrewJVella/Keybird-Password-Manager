python3 ./src/main.py
